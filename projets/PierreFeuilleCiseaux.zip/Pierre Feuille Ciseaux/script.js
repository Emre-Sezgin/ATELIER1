const choix = document.querySelectorAll("button")
// Permet la création d'une liste pour les bouttons

function playSound () {
    document.getElementById('play').play();
}

var scoreJ = 0;
var scoreR = 0;
var resultat = ""

for (let i = 0; i < choix.length; i++){
	choix[i].addEventListener("click", function(){
	// On va écouter le clic du visiteur
		 
		var joueur = choix[i].innerHTML
		// On va mettre dans la variable joueur ce que le joueur à cliqué

		var robot = choix[Math.floor(Math.random() * choix.length)].innerHTML
		// math random va générer un nombre au hasard (entre 0 et 1) * la taille du tableau (0 1 2)               			
		// math.floor permet d'arrondir le resultat, ce qui permettra un choix entre 0 1 2 (les 3 bouttons pierre feuille ciseaux)      EXEMPLE: 0.67 = 1 donc boutton pierre
		
		if(scoreJ > 2){
				alert("FELICITATION! VOUS AVEZ GAGNÉ");
			  	setTimeout(function() {
        		document.location.reload()
  				}, 0);
		}
		
		else if(scoreR > 2){
				alert("QUEL DOMMAGE... VOUS AVEZ PERDU! ");
			  	setTimeout(function() {
        		document.location.reload()
  				}, 0);
		}
		 
		else if(joueur === robot){
		 	resultat = "Egalité"
		}

		else if ((joueur === "✊" && robot === "✌") || (joueur === "✋" && robot === "✊") || (joueur === "✌" && robot === "✋")){
			resultat = "Gagné"
			scoreJ++
		}
		
		else{
			resultat = "Perdu"
			scoreR++
		}

		document.querySelector(".resultat").innerHTML = 
		 `
		 	Joueur : ${joueur} Robot : ${robot} </br></br>
		 	${resultat}  </br></br>
		 	${scoreJ}-${scoreR}
		 `
		 // QuerySelector permet de modifier un élément grâce à ses attributs
		
	})


}